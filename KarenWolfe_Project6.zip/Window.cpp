#include <iostream>

#ifdef __APPLE__
    #include <GLUT/glut.h>
#else
    #include <GL/glut.h>
#endif

#include "Window.h"
#include "Cube.h"
#include "Matrix4.h"
#include "Globals.h"
#include "Drawable.h"
#include "Geode.h"
#include "MatrixTransform.h"
#include "Group.h"



int Window::width  = 512;   //Set window width in pixels here
int Window::height = 512;   //Set window height inpixels here
Group Window::root = Group();
Group Window::terr = Group();
float prev_y = 0;

void Window::initialize(void)
{
    //Setup the light
    Vector4 lightPos(0.0, 10.0, 15.0, 1.0);
    Globals::light.position = lightPos;
    Globals::light.quadraticAttenuation = 0.02;

    
    //Setup the cube's material properties
    Color color(Color::white());
    //Globals::shape->material.color = color;
    //Setup obj material properties

    /*Initialize the skybox textures*/
    Globals::skybox.top = new Texture("/Users/karen/cse167/Project1/s_up.ppm");
    Globals::skybox.bottom = new Texture("/Users/karen/cse167/Project1/s_down.ppm");
    Globals::skybox.left = new Texture("/Users/karen/cse167/Project1/s_right.ppm");
    Globals::skybox.right = new Texture("/Users/karen/cse167/Project1/s_left.ppm");
    Globals::skybox.front = new Texture("/Users/karen/cse167/Project1/s_front.ppm");
    Globals::skybox.back = new Texture("/Users/karen/cse167/Project1/s_back.ppm");

    Texture* surfaceText = new Texture("/Users/karen/cse167/Project1/cat_face4.ppm");
    Texture* cylinBot = new Texture("/Users/karen/cse167/Project1/cat_fur.ppm");
    Texture* cylinTop = new Texture("/Users/karen/cse167/Project1/cat_fur.ppm");
    Texture* cylinBody = new Texture("/Users/karen/cse167/Project1/iron.ppm");
    Globals::t.push_back(surfaceText);
    Globals::t.push_back(cylinTop);
    Globals::t.push_back(cylinBot);
    Globals::t.push_back(cylinBody);
    
    Globals::android.setTextures(Globals::t);
    //root.addChild(&Globals::android);
    if(Globals::army)
        root.draw(Matrix4().setIdentity());
    Globals::androidPlacement->addChild(&Globals::ground);
    Globals::androidPlacement->addChild(Globals::light_path);

    setUpArmy();
    Globals::light_path->addChild(&Globals::pl);
 //   root.addChild(Globals::light_path);
    //root.addChild(&Globals::ground);
    
    Globals::tran = new MatrixTransform(Matrix4().makeTranslate(-1024/2, 0, 0));
    Globals::terrain.init("/Users/karen/cse167/Project1/terrain.ppm");
    Globals::tran->addChild(&Globals::terrain);
    Globals::tran->addChild(Globals::light_path);
    terr.addChild(Globals::tran);
    
    //terr.addChild(Globals::light_path);
    
    Globals::shader = new Shader("/Users/karen/cse167/Project1/diffuse_only.vert", "/Users/karen/cse167/Project1/diffuse_only.frag");
    //Globals::shader->printLog();

}

//----------------------------------------------------------------------------
// Callback method called when system is idle.
// This is called at the start of every new "frame" (qualitatively)
void Window::idleCallback()
{
    //Set up a static time delta for update calls
    Globals::updateData.dt = 1.0/60.0;// 60 fps
    root.update();
    terr.update();
    terr.removeChild(Globals::tran);
    Globals::tran->removeChild(Globals::light_path);
    Globals::light_path->trans = Matrix4().makeTranslate((Globals::pl.position.toVector3()));
    Globals::tran->addChild(Globals::light_path);
    terr.addChild(Globals::tran);
    
    
    //Rotate cube; if it spins too fast try smaller values and vice versa
   // Globals::shape->idle();
    
    //Call the update function on cube
   // Globals::shape->update(Globals::updateData);
    
    //Call the display routine to draw the cube
    displayCallback();
}

//----------------------------------------------------------------------------
// Callback method called by GLUT when graphics window is resized by the user
void Window::reshapeCallback(int w, int h)
{
    width = w;                                                       //Set the window width
    height = h;                                                      //Set the window height
    

    glViewport(0, 0, w, h);           //Set new viewport size
    glMatrixMode(GL_PROJECTION);      //Set the OpenGL matrix mode to Projection
    glLoadIdentity();                 //Clear the projection matrix by loading the identity
    gluPerspective(60.0, double(width)/(double)height, 1.0, 2000.0); //Set perspective projection viewing frustum


    Globals::rasterizer.reshape(width,height);
}

//----------------------------------------------------------------------------
// Callback method called by GLUT when window readraw is necessary or when glutPostRedisplay() was called.
void Window::displayCallback()
{
    
    Globals::rasterizer.clearBuffer();    //Clear color and depth buffers
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    //Set the OpenGL matrix mode to ModelView
    glMatrixMode(GL_MODELVIEW);
    
    //Push a matrix save point
    //This will save a copy of the current matrix so that we can
    //make changes to it and 'pop' those changes off later.
    glPushMatrix();
    
    //Replace the current top of the matrix stack with the inverse camera matrix
    //This will convert all world coordiantes into camera coordiantes
    glLoadMatrixf(Globals::camera.getInverseMatrix().ptr());
   
    //Bind the light to slot 0.  We do this after the camera matrix is loaded so that
    //the light position will be treated as world coordiantes
    //(if we didn't the light would move with the camera, why is that?)
    Globals::dl.bind(1, Matrix4().setIdentity());
    Globals::pl.bind(0,Matrix4().makeTranslate((Globals::pl.position.toVector3())));
    //Globals::pl.draw(Matrix4().makeTranslate((Globals::pl.position.toVector3())));
    //Globals::sl.bind(3);
    //Globals::sl.draw(Globals::drawData);
    
    if(Globals::army)
        root.draw(Matrix4().setIdentity());
//    else if(Globals::cow_mode)
//        Globals::cow.draw(Globals::drawData);
    else
        terr.draw(Matrix4().setIdentity());
        //Globals::terrain.draw(Matrix4().setIdentity());
        //
    Globals::skybox.draw(Matrix4().setIdentity());
    //Globals::cyl.draw(Globals::drawData);
    
    //Pop off the changes we made to the matrix stack this frame
    glPopMatrix();
    
    //Tell OpenGL to clear any outstanding commands in its command buffer
    //This will make sure that all of our commands are fully executed before
    //we swap buffers and show the user the freshly drawn frame
    
    if(Globals::flag_OpenGL)
        glFlush();
    else
        Globals::rasterizer.display();
    
    //Swap the off-screen buffer (the one we just drew to) with the on-screen buffer
    glutSwapBuffers();
}


//TODO: Keyboard callbacks!
void Window::processNormalKeys(unsigned char key, int x, int y) {
    //Matrix4 rotation;
    Vector3 position(0, 0, 0);
    int mod = glutGetModifiers();
    if (mod == GLUT_ACTIVE_CTRL){
        Globals::flag_MouseScroll = !Globals::flag_MouseScroll;
        //std::cout << "Balalalalalala" << std::endl;
    }
    
    switch(key) {
        /*Toggle direction of spin between clockwise and counterclockwise*/
        case 't' :{
            //if(Globals::shape == &Globals::cube)
            Globals::cube.spinAmt = -1 * Globals::cube.spinAmt;
            //Globals::spinAmt = -1 * Globals::spinAmt;
            break;
        }
        /*Move cube left by a small amount*/
        case 'x' :{
            Matrix4 xTrans;
            xTrans.makeTranslate(-1, 0, 0);
            //Globals::shape->toWorld = xTrans * Globals::shape->toWorld;
            break;
        }
        /*Move cube right by a small amount*/
        case 'X' :{
            Matrix4 xTrans;
            xTrans.makeTranslate(1, 0, 0);
            //Globals::shape->toWorld = xTrans * Globals::shape->toWorld;
            break;
        }
        /*Move cube down by a small amount*/
        case 'y' :{
            Matrix4 yTrans;
            yTrans.makeTranslate(0, -1, 0);
            //Globals::shape->toWorld = yTrans * Globals::shape->toWorld;
            break;
        }
        /*Move cube up by a small amount*/
        case 'Y' :{
            Matrix4 yTrans;
            yTrans.makeTranslate(0, 1, 0);
            //Globals::shape->toWorld = yTrans * Globals::shape->toWorld;
            break;
        }
        /*Move cube into screen by a small amount*/
        case 'z' :{
            Matrix4 zTrans;
            zTrans.makeTranslate(0, 0, -1);
            //Globals::shape->toWorld = zTrans * Globals::shape->toWorld;
            break;
        }
        /*Move cube out of screen by a small amount*/
        case 'Z' :{
            Matrix4 zTrans;
            zTrans.makeTranslate(0, 0, 1);
            //Globals::shape->toWorld = zTrans * Globals::shape->toWorld;
            break;
        }
        /*Reset cube position, orientation, and size*/
        case 'r' :
            if(Globals::cube.spinAmt < 0)
                Globals::cube.spinAmt = -1 * Globals::cube.spinAmt;
            //Globals::shape->toWorld.identity();
            break;
        /*Orbit cube around OpenGL window's z axis by a small number of degrees counterclockwise
         *without affecting the spin itself (other than spinning axis)*/
        case 'o' :{
            Matrix4 zRotate;
            zRotate.makeRotateZ(.05);
            //Globals::shape->toWorld = zRotate * Globals::shape->toWorld;
            break;
        }
        /*Orbit cube around OpenGL window's z axis by a small number of degrees clockwise
         *without affecting the spin itself (other than spinning axis)*/
        case 'O' :{
            Matrix4 zRotate;
            zRotate.makeRotateZ(-.05);
            //Globals::shape->toWorld = zRotate * Globals::shape->toWorld;
            break;
        }
        /*Scale cube down about its center*/
        case 's' :{
            Matrix4 scaleD;
            scaleD.makeScale(.95);
            if(Globals::army){
                root.removeChild(Globals::androidPlacement);
                Globals::androidPlacement->trans = scaleD * Globals::androidPlacement->trans;
                root.addChild(Globals::androidPlacement);
            }
            else{
                terr.removeChild(Globals::tran);
                Globals::tran->trans = scaleD * Globals::tran->trans;
                terr.addChild(Globals::tran);
            }
            //Globals::shape->toWorld = Globals::shape->toWorld * scaleD;
            break;
        }
        /*Scale cube up about its center*/
        case 'S' :{
            Matrix4 scaleU;
            scaleU.makeScale(1.05);
            if(Globals::army){
                root.removeChild(Globals::androidPlacement);
                Globals::androidPlacement->trans = scaleU * Globals::androidPlacement->trans;
                root.addChild(Globals::androidPlacement);
            }
            else{
                terr.removeChild(Globals::tran);
                Globals::tran->trans = scaleU * Globals::tran->trans;
                terr.addChild(Globals::tran);
            }
            //Globals::shape->toWorld = Globals::shape->toWorld * scaleU;
            break;
        }
        case 'b' :{
            //Initialize cube matrix:
            Globals::shape = &Globals::sphere;
            //Globals::sphere.toWorld.identity();
            
            //Setup the cube's material properties
            Color color(0x23ff27ff);
            //Globals::sphere.material.color = color;
            break;
        }
        case 'e':{
            Globals::flag_OpenGL = !Globals::flag_OpenGL;
            break;
        }
        case '+':{
            if(Globals::part < 4)
                Globals::part = ++Globals::part;
            break;
        }
        case '-':{
            if(Globals::part > 1)
                Globals::part = --Globals::part;
            break;
        }
            
        case '1':{
            Globals::dl_on = !Globals::dl_on;
            if(Globals::dl_on)
                std::cout <<  "Directional Light Selected" << std::endl;
            if(!Globals::dl_on)
                std::cout <<  "Directional Light De-selected" << std::endl;
            break;
        }
        case '2':{
            Globals::pl_on = !Globals::pl_on;
            if(Globals::pl_on)
                std::cout <<  "Point Light Selected" << std::endl;
            if(!Globals::pl_on)
                std::cout <<  "Point Light De-selected" << std::endl;
            break;
        }
        case '3':{
            Globals::sl_on = !Globals::sl_on;
            if(Globals::sl_on)
                std::cout <<  "Spot Light Selected" << std::endl;
            if(!Globals::sl_on)
                std::cout <<  "Spot Light De-selected" << std::endl;
            break;
        }
   
            
        case 27 :
            exit(0);
    }
    
    
    
    //position[0] = Globals::shape->toWorld.get(3,0);
    //position[1] = Globals::shape->toWorld.get(3,1);
    //position[2] = Globals::shape->toWorld.get(3,2);
    //position.print("Position Coordinates:");
    //Globals::shape->update(Globals::updateData);
    displayCallback();


}

//Function Key callbacks!
void Window::processFuncKeys(int key, int x, int y){
    
    
    switch(key) {
        case GLUT_KEY_F1:
            Globals::army = true;
            Globals::group_sel = &root;
            //Globals::shape = &Globals::cube;
            Globals::camera.set(Globals::eDefault, Globals::dDefault, Globals::upDefault);
            glEnable(GL_LIGHTING);
            break;
        case GLUT_KEY_F2:
            Globals::army = false;
            Globals::group_sel = &terr;
            Globals::camera.set(Globals::img1e, Globals::dDefault, Globals::upDefault);
           // Globals::shape = &Globals::house;
            //Globals::camera.set(Globals::img1e, Globals::img1d, Globals::img1up);
            glDisable(GL_LIGHTING);
            break;
        case GLUT_KEY_F3:
            //Globals::shape = &Globals::house;
            //Globals::camera.set(Globals::img2e, Globals::img2d, Globals::img2up);
            glDisable(GL_LIGHTING);
            break;
        case GLUT_KEY_F4:
            Globals::shape = &Globals::bunny;
            Globals::camera.set(Globals::eDefault, Globals::dDefault, Globals::upDefault);
            glEnable(GL_LIGHTING);
            break;
        case GLUT_KEY_F5:
            Globals::shape = &Globals::dragon;
            Globals::camera.set(Globals::eDefault, Globals::dDefault, Globals::upDefault);
            glEnable(GL_LIGHTING);
            break;
        case GLUT_KEY_F6:
            Globals::shape = &Globals::bear;
            Globals::camera.set(Globals::eDefault, Globals::dDefault, Globals::upDefault);
            glEnable(GL_LIGHTING);
            break;
            
        case GLUT_KEY_F7:
            Globals::cow_mode = true;
            Globals::army = false;
//            Globals::shape = &Globals::cow;
            Globals::camera.set(Globals::eDefault, Globals::dDefault, Globals::upDefault);
            glEnable(GL_LIGHTING);
            break;
            
        case GLUT_KEY_UP:{
            //do something here
            Matrix4 zRotate;
            zRotate.makeRotateX(.05);
            //Globals::shape->toWorld = Globals::shape->toWorld * zRotate;
            break;
        }
        case GLUT_KEY_DOWN:{
            Matrix4 zRotate;
            zRotate.makeRotateX(-.05);
           // Globals::shape->toWorld = Globals::shape->toWorld * zRotate;
            //do something here
            break;
        }
        case GLUT_KEY_LEFT:{
            Matrix4 spinL;
            spinL.makeRotateY(-.05);
            //Globals::shape->toWorld = Globals::shape->toWorld * spinL;
            break;
        }
        case GLUT_KEY_RIGHT:{
            Matrix4 spinR;
            spinR.makeRotateY(.05);
            //Globals::shape->toWorld = Globals::shape->toWorld * spinR;
            break;
        }
    }

}

/*TODO: how to process motion while being clicked???*/
void Window::processMouse(int button, int state, int x, int y){
    switch(button){
        case GLUT_LEFT_BUTTON:
            //process left button clicky stuff
            Globals::movement = MOUSE_LEFT;
            Globals::lastPoint = trackballMapping(Vector3(x,y,0));
            prev_y = y;
            //Save mouse position as logical sphere location, store as lastPoint
            break;
        case GLUT_RIGHT_BUTTON:
            Globals::movement = MOUSE_RIGHT;
            Globals::lastPoint[0] = x;
            Globals::lastPoint[1] = y;
            break;
        case MOUSE_WHEEL:
            break;
            
    }
}

void Window::processMouseMovement(int x, int y){
    Vector3 direction;
   // float pixel_dif;
    float rot_angle;//, zoom_factor;
    Vector3 currPoint;
    float updwn = prev_y - y;
    prev_y = y;
    switch(Globals::movement){
        case MOUSE_LEFT: {
            
            currPoint = trackballMapping(Vector3(x,y,0));
            direction = currPoint - Globals::lastPoint;
            float velocity = direction.magnitude();
            if(velocity > .0001){
                Vector3 rot_axis;
                rot_axis = Globals::lastPoint.cross(currPoint);
                rot_angle = velocity * ROT_SCALE;
                Matrix4 rm;
                rm = rm.makeRotateArbitrary(rot_axis, rot_angle);
                if(Globals::army){
                    root.removeChild(Globals::androidPlacement);
                    //Globals::androidPlacement->removeChild(&Globals::androidArmy);
                    Globals::androidPlacement->trans = rm * Globals::androidPlacement->trans;
                    //Globals::androidPlacement->addChild(&Globals::androidArmy);
                    root.addChild(Globals::androidPlacement);
                //Globals::shape->data.c = rm * Globals::shape->data.c;
                }
                else{
                    if(x < 100){
                        terr.removeChild(Globals::tran);
                        Globals::tran->removeChild(&Globals::terrain);
                        //Globals::androidPlacement->removeChild(&Globals::androidArmy);
                        Globals::terrain.heighten(updwn);
                        Globals::tran->addChild(&Globals::terrain);
                        //Globals::androidPlacement->addChild(&Globals::androidArmy);
                        terr.addChild(Globals::tran);

                    }
                    else if (x > width-100){
                        Globals::terrain.update_levels(direction[1]);
                    }
                    else{
                    terr.removeChild(Globals::tran);
                    //Globals::androidPlacement->removeChild(&Globals::androidArmy);
                    Globals::tran->trans = rm * Globals::tran->trans;
                    //Globals::androidPlacement->addChild(&Globals::androidArmy);
                    terr.addChild(Globals::tran);
                    }
                }
//                if(Globals::dl_on)
//                    Globals::dl.toWorld = rm * Globals::dl.toWorld;
//                if(Globals::pl_on)
//                    Globals::pl.toWorld = rm * Globals::pl.toWorld;
//                if(Globals::sl_on)
//                    Globals::sl.toWorld = rm * Globals::sl.toWorld;
                // Globals::shape->toWorld.print("toWord matrix");
                Globals::lastPoint = currPoint;
                
                
            }
            break;
        }
        case MOUSE_RIGHT:{
            currPoint = Vector3(x, y, 0);
            Matrix4 trans;
            trans = trans.makeTranslate((x - Globals::lastPoint[0])*0.05,
                                        (y -Globals::lastPoint[1])*-0.05, 0);
            if(Globals::army){
                root.removeChild(Globals::androidPlacement);
                Globals::androidPlacement->trans = trans * Globals::androidPlacement->trans;
                root.addChild(Globals::androidPlacement);
               // Globals::shape->toWorld = trans * Globals::shape->toWorld;
            }
            else{
                terr.removeChild(Globals::tran);
                //Globals::androidPlacement->removeChild(&Globals::androidArmy);
                Globals::tran->trans = trans * Globals::tran->trans;
                //Globals::androidPlacement->addChild(&Globals::androidArmy);
                terr.addChild(Globals::tran);
            }
            //if(Globals::dl_on){}
                //Globals::dl.toWorld = trans * Globals::dl.toWorld;
//            if(Globals::pl_on)
//                Globals::pl.toWorld = trans * Globals::pl.toWorld;
//            if(Globals::sl_on){
//                Globals::sl.angle = Globals::sl.angle + (y -Globals::lastPoint[1])*-0.1;
//                Globals::sl.cosine_exp = Globals::sl.cosine_exp + (x -Globals::lastPoint[0])*0.1;
//               // Globals::sl.toWorld = trans * Globals::sl.toWorld;
           // }
            Globals::lastPoint = currPoint;

            break;
        }
        case MOUSE_WHEEL:
            std::cout << "yoyoyoyo" << std::endl;
            break;
        
    }
    
}

void Window::processPassiveMouse(int x, int y){
    if(Globals::flag_MouseScroll){
        //Vector3 currPoint = Vector3(Globals::lastPoint, y, 0);
        Matrix4 mz;
        //Globals::lastPoint[2] = Globals::lastPoint[2] - y;
        mz = mz.makeTranslate(0, 0, (Globals::lastPoint[1]-y) * -0.05);
        if(Globals::army){
            root.removeChild(Globals::androidPlacement);
            Globals::androidPlacement->trans = mz * Globals::androidPlacement->trans;
            root.addChild(Globals::androidPlacement);
        }
        else{
            terr.removeChild(Globals::tran);
            Globals::tran->trans = mz * Globals::tran->trans;
            terr.addChild(Globals::tran);
        }
          //  Globals::shape->toWorld = mz * Globals::shape->toWorld;
       // if(Globals::dl_on)
         //   Globals::dl.toWorld = mz * Globals::dl.toWorld;
//        if(Globals::pl_on)
//            Globals::pl.toWorld = mz * Globals::pl.toWorld;
//        if(Globals::sl_on)
//            Globals::sl.toWorld = mz * Globals::sl.toWorld;
//        //Globals::flag_MouseScroll = false;

    }
    Globals::lastPoint = Vector3(x,y,0);


}

Vector3 Window::trackballMapping(Vector3 point){
    Vector3 v;
    float d;
    
    v[0] = (2.0*point[0] - width)/width;
    v[1] = (height - 2.0*point[1])/height;
    v[2] = 0;
    
    d = v.magnitude();
    
    d = (d < 1.0) ? d : 1.0;
    v[2] = sqrtf(1.001 - d*d);
    v = v.normalize();
    
    return v;
}


//TODO: Mouse callbacks!

//TODO: Mouse Motion callbacks!

void Window::setUpArmy(){
    for(int r = -5; r < 5; r++){
        for(int c = 0; c < 10; c++){
            float row = r*8.0;
            float col = c*-8.0;
            Matrix4 translate = Matrix4().makeTranslate(row, 0.0, col);
            MatrixTransform* armyPlacement = new MatrixTransform(translate);
            armyPlacement->addChild(&Globals::android);
            Globals::androidArmy.addChild(armyPlacement);
        }
    }
    Globals::androidPlacement->addChild(&Globals::androidArmy);
//    Matrix4 armyMove = Matrix4().makeTranslate(0.0, -10.0, -10.0);
//    MatrixTransform* set = new MatrixTransform(armyMove);
//    set->addChild(&Globals::androidArmy);
//    root.addChild(set);
    root.addChild(Globals::androidPlacement);
}

