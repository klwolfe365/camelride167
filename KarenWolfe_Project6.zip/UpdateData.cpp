#include "UpdateData.h"

UpdateData::UpdateData(void)
{
    this->dt = 1.0;
}

UpdateData::~UpdateData(void)
{
    //
}
