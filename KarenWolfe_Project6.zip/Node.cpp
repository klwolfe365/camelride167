//
//  Node.cpp
//  CSE167 Spring 2015 Starter Code
//
//  Created by Karen Wolfe on 5/7/15.
//  Copyright (c) 2015 RexWest. All rights reserved.
//

#include "Node.h"
#include "Matrix4.h"

Node::Node(){}
Node::~Node(){}

void Node::draw(Matrix4 c){}
void Node::update(){}
