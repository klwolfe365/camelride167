//
//  Terrain.h
//  CSE167 Spring 2015 Starter Code
//
//  Created by Karen Wolfe on 5/14/15.
//  Copyright (c) 2015 RexWest. All rights reserved.
//

#ifndef __CSE167_Spring_2015_Starter_Code__Terrain__
#define __CSE167_Spring_2015_Starter_Code__Terrain__

#include <stdio.h>
#include "Vector3.h"
#include "Texture.h"
#include "Node.h"

class Terrain : public Node{
public:
    unsigned char* height_map;
    Vector3 coords[1024][1024];
    Vector3 normal[1024][1024];
    int num_vert;
    int num_ind;
    int width;
    int height;
    float max_height;
    float band_height;
    Texture * map_texture;

    Terrain();
    ~Terrain();
    
    bool init(const char * ppmFile);
    void draw(Matrix4 c);
    void update();
    
    void heighten(int y);
    void setNormals();
    void update_levels(float y);
    Vector4 getColor(float y);
    float getLevel(float y);
    //ex*heitmap y 
    
};
#endif /* defined(__CSE167_Spring_2015_Starter_Code__Terrain__) */
