//
//  PointLight.cpp
//  CSE167 Spring 2015 Starter Code
//
//  Created by Karen Wolfe on 4/30/15.
//  Copyright (c) 2015 RexWest. All rights reserved.
//

#include "PointLight.h"

PointLight::PointLight() : Light() {
    diffuseColor = Color(0.5,0.0,0.5);
    //ambientColor = Color(.2,.2,.2);
    specularColor = diffuseColor;
    position = Vector4(0.0,0.0,0.0,1.0);
    
    //calculate specular reflectance
    //specularColor = Color(1.0,1.0,1.0);
    

}

PointLight::~PointLight(){}

void PointLight::draw(DrawData&){
   /* glPushMatrix();
    glLoadIdentity();*/
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glMultMatrixf(toWorld.ptr());
    
    glColor3f(.5,0.0,.5);
    
    //glTranslated(position[0], position[1], position[2]);
    glutSolidSphere(0.75, 20, 20);
    glPopMatrix();

}
void PointLight::update(UpdateData&){}
void PointLight::idle(){}

void PointLight::myDraw(DrawData&){}