#ifndef CSE167_Sphere_h
#define CSE167_Sphere_h

#include <iostream>
#include "Drawable.h"
#include "Vector3.h"
#include "Window.h"

class Sphere : public Drawable
{
    
public:
    
    double radius;
    int slices, stacks;
    static Vector3 velocity;
    static float gravity;


    
    Sphere(double, int, int);
    
    virtual void draw(DrawData&);
    virtual void update(UpdateData&);
    void runPhysics(float dt);
    virtual void idle();
    
};

#endif
