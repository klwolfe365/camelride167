#include "Globals.h"

Camera Globals::camera = Camera();

Cube Globals::cube = Cube(10.0);
Sphere Globals::sphere = Sphere(2.5, 100.0, 100.0);

Vector3 Globals::eDefault(0.0, 0.0, 20.0);
Vector3 Globals::dDefault(0.0, 0.0, 0.0);
Vector3 Globals::upDefault(0.0, 1.0, 0.0);

House Globals::house = House();
Vector3 Globals::img1e(0.0, 24.14, 24.14);
Vector3 Globals::img1d(0.0, 0.0, 0.0);
Vector3 Globals::img1up(0.0, 1.0, 0.0);
Vector3 Globals::img2e(-28.33, 11.66, 23.33);
Vector3 Globals::img2d(-5.0, 0.0, 0.0);
Vector3 Globals::img2up(0.0, 1.0, 0.5);

OBJObject Globals::bunny = OBJObject("/Users/karen/cse167/Project1/bunny.obj");
OBJObject Globals::dragon = OBJObject("/Users/karen/cse167/Project1/dragon.obj");
OBJObject Globals::bear = OBJObject("/Users/karen/cse167/Project1/bear.obj");

Light Globals::light = Light();

DrawData Globals::drawData = DrawData();
UpdateData Globals::updateData = UpdateData();

float Globals::spinAmt = .0025;

Drawable *Globals::shape = &Globals::cube;

Rasterizer Globals::rasterizer = Rasterizer();
bool Globals::flag_OpenGL = true;

int Globals::part = 1;


int Globals::movement = -1;
Vector3 Globals::point;
Vector3 Globals::lastPoint;
bool Globals::flag_MouseScroll = false;

DirectionalLight Globals::dl = DirectionalLight();
PointLight Globals::pl = PointLight();
SpotLight Globals::sl = SpotLight();

bool Globals::pl_on = false;
bool Globals::sl_on = false;
bool Globals::dl_on = false;

bool Globals::white_mode = true;
Material Globals::defaultMaterial = Material(Color::ambientMaterialDefault(), Color::diffuseMaterialDefault(), Color::specularMaterialDefault(), Color::emissionMaterialDefault(), Color::white(), 0);
Material Globals::bunnyMat = Material(Color(0.0,1.0,0.0), Color::diffuseMaterialDefault(), Color::specularMaterialDefault(), Color::emissionMaterialDefault(), Color(0,1.0,0), 100);


